# HUD Maestro CASMONT·COP · Producción

Sistema multisensorial plug-and-play con backend Express, HUD visual, marcador en tiempo real y generación de NFT educativos.

## 🔧 Instalación

```bash
chmod +x ritual_casmont_hud.sh
./ritual_casmont_hud.sh

