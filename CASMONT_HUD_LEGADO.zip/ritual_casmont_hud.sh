#!/bin/bash
set -e

PROJECT_DIR="${HOME}/backend_hud"
mkdir -p "$PROJECT_DIR"
cd "$PROJECT_DIR"

echo "⚙️ Preparando entorno en $PROJECT_DIR"

# 1) package.json y dependencias
if [ ! -f package.json ]; then
  npm init -y >/dev/null
fi

need_install=false
for pkg in express cors body-parser sqlite3; do
  node -e "require.resolve('$pkg')" 2>/dev/null || need_install=true
done
if [ "$need_install" = true ]; then
  echo "📦 Instalando dependencias..."
  npm install express cors body-parser sqlite3 >/dev/null
fi

# 2) Base de datos SQLite
cat > init_db.js <<'EOF'
const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database('hud.db');
db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS metricas (
    clave TEXT PRIMARY KEY,
    valor TEXT
  )`);
  db.run(`CREATE TABLE IF NOT EXISTS hitos (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    solucion TEXT,
    hito TEXT,
    fecha TEXT
  )`);
  const soluciones = [
    "video_ia_viral_pro",
    "app_web_express",
    "avatar_ia_realista",
    "identidad_digital_pro",
    "narrador_multimedia_ia",
    "serie_automatizada_ia",
    "app_premium_creator_seed",
    "mentoria_publica_nft"
  ];
  soluciones.forEach(sol => {
    db.run(`INSERT OR IGNORE INTO metricas (clave, valor) VALUES (?, ?)`, [`activaciones-${sol}`, "0"]);
    db.run(`INSERT OR IGNORE INTO metricas (clave, valor) VALUES (?, ?)`, [`ingresos-${sol}`, "$0"]);
  });
});
db.close();
EOF
node init_db.js

# 3) Backend Express
cat > server.js <<'EOF'
const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const PORT = process.env.PORT || 3000;
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('.'));

function getDB() {
  return new sqlite3.Database('hud.db');
}

app.get('/api/metricas', (req, res) => {
  const db = getDB();
  db.all(`SELECT clave, valor FROM metricas`, [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    const data = {};
    rows.forEach(r => data[r.clave] = r.valor);
    res.json(data);
    db.close();
  });
});

app.get('/api/export', (req, res) => {
  const db = getDB();
  db.all(`SELECT * FROM hitos`, [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
    db.close();
  });
});

app.post('/api/eventos', (req, res) => {
  const { solucion, tipo, fecha } = req.body;
  console.log(`📌 Evento recibido: ${solucion} - ${tipo} @ ${fecha}`);
  if (tipo === 'activacion') {
    const key = `activaciones-${solucion}`;
    const db = getDB();
    db.get(`SELECT valor FROM metricas WHERE clave=?`, [key], (err, row) => {
      if (!err && row) {
        const nuevo = parseInt(row.valor) + 1;
        db.run(`UPDATE metricas SET valor=? WHERE clave=?`, [nuevo.toString(), key]);
        console.log(`✅ Activaciones de ${solucion}: ${nuevo}`);
      }
      db.close();
    });
  }
  res.json({ status: 'ok' });
});

app.post('/api/hitos', (req, res) => {
  const { solucion, hito, fecha } = req.body;
  console.log(`🏆 Hito registrado: ${hito} para ${solucion} @ ${fecha}`);
  const db = getDB();
  db.run(`INSERT INTO hitos (solucion, hito, fecha) VALUES (?, ?, ?)`, [solucion, hito, fecha]);
  db.close();
  const nft = { nombre: `NFT-${Date.now()}` };
  res.json({ nft });
});

app.listen(PORT, () => console.log(`🚀 Backend HUD Maestro corriendo en http://localhost:${PORT}`));
EOF

# 4) HUD Maestro con 8 tarjetas y confeti
cat > hud_maestro.html <<'EOF'
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <title>HUD Maestro CASMONT·COP</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700&display=swap" rel="stylesheet">
  <style>
    :root{--bg:#111;--panel:#1a1a1a;--cian:#00d4ff;--verde:#0fff95;--oro:#ffcc00;--text:#fff;}
    body{margin:0;background:var(--bg);color:var(--text);font-family:'Orbitron',sans-serif}
    .hud-maestro{padding:2rem;max-width:1280px;margin:auto}
    h2{margin:0 0 1rem}
    .grid-hud{display:grid;grid-template-columns:repeat(auto-fit,minmax(320px,1fr));gap:1.25rem}
    .hud-card{background:var(--panel);border:2px solid var(--cian);border-radius:14px;padding:1rem}
    .hud-card h3{color:var(--verde);margin:.25rem 0 .75rem}
    .ceremonial{font-size:.8rem;color:var(--oro)}
    .btn-activar{margin:.3rem .3rem .8rem 0;background:var(--cian);color:#111;border:none;padding:.55rem .9rem;border-radius:8px;font-weight:700;cursor:pointer}
    .btn-activar:hover{filter:brightness(1.1)}
    .ritual-overlay{position:fixed;inset:0;background:rgba(17,17,17,.88);display:flex;align-items:center;justify-content:center;opacity:0;pointer-events:none;transition:opacity .6s ease;z-index:9999}
    .ritual-overlay.mostrar{opacity:1;pointer-events:auto}
    .ritual-contenido{background:#1a1a1a;border:3px solid var(--cian);border-radius:18px;padding:2rem;text-align:center;box-shadow:0 0 24px var(--cian)}
    .ritual-contenido h2{color:var(--verde);margin:.25rem 0 1rem}
    .ritual-contenido p{color:var(--oro);margin:0}
  </style>
</head>
<body>
<section class="hud-maestro">
  <h2>HUD Maestro – Panel Interno CASMONT·COP</h2>
  <div class="grid-hud"></div>
</section>
<div class="ritual-overlay" id="ritualOverlay">
  <div class="ritual-contenido">
    <h2>🎉 Hito alcanzado</h2>
    <p>NFT generado</p>
  </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/canvas-confetti@1.6.0/dist/confetti.browser.min.js"></script>
<script>
const soluciones = [
  "video_ia_viral_pro",
  "app_web_express",
  "avatar_ia_realista",
  "identidad_digital_pro",
  "narrador_multimedia_ia",
  "serie_automatizada_ia",
  "app_premium_creator_seed",
  "mentoria_publica_nft"
];
const grid = document.querySelector('.grid-hud');
soluciones.forEach(sol => {
  const card = document.createElement('div');
  card.className = 'hud-card';
  let estiloExtra = '';
  if (sol === "mentoria_publica_nft") {
    estiloExtra = 'style="border-color: var(--oro); box-shadow: 0 0 18px var(--oro);"';
  }
  card.innerHTML = `
    <div ${estiloExtra}>
      <h3>${sol}</h3>
      <p class="ceremonial">Activaciones: <span id="activaciones-${sol}">0</span></p>
      <button class="btn-activar"
            <button class="btn-activar" onclick="registrarEvento('${sol}','video_click')">🔗 Click</button>
      <button class="btn-activar" onclick="completarHito('${sol}','Hito logrado')">🎉 Hito</button>
    </div>
  `;
  grid.appendChild(card);
});

function registrarEvento(solucion, tipo) {
  fetch('/api/eventos', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ solucion, tipo, fecha: new Date().toISOString() })
  }).then(() => actualizarMetricas());
}

function completarHito(solucion, hito) {
  fetch('/api/hitos', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({ solucion, hito, fecha: new Date().toISOString() })
  }).then(res => res.json()).then(data => {
    console.log("🎉 NFT generado:", data.nft);
    lanzarConfeti();
    mostrarOverlay();
  });
}

function actualizarMetricas() {
  fetch('/api/metricas')
    .then(res => res.json())
    .then(data => {
      Object.keys(data).forEach(k => {
        const el = document.getElementById(k);
        if (el) el.textContent = data[k];
      });
    });
}

function lanzarConfeti() {
  confetti({ particleCount: 120, spread: 80, origin: { y: 0.6 } });
}

function mostrarOverlay() {
  const overlay = document.getElementById('ritualOverlay');
  overlay.classList.add('mostrar');
  setTimeout(() => overlay.classList.remove('mostrar'), 3000);
}

actualizarMetricas();
</script>
</body>
</html>
EOF

# 5) Ritual de arranque con firma y sonido
echo -e "\n"
echo "╔════════════════════════════════════════════╗"
echo "║   CASMONT·COP · HUD Maestro · Producción   ║"
echo "╚════════════════════════════════════════════╝"
echo "⏳ Inicializando ritual multisensorial..."

sleep 1
echo "🔧 Ensamblando HUD Maestro..."
sleep 1
echo "📡 Conectando backend y base de datos..."
sleep 1
echo "🎨 Activando estilo visual y confeti..."
sleep 1
echo "🎉 Preparando marcador celebrativo..."
sleep 1

# Sonido ritual (si el sistema lo permite)
if command -v paplay >/dev/null; then
  paplay /usr/share/sounds/freedesktop/stereo/complete.oga &
elif command -v afplay >/dev/null; then
  afplay /System/Library/Sounds/Glass.aiff &
fi

# Lanzar backend
node server.js &
BACKEND_PID=$!
sleep 1
echo "✅ Ritual completado. Lanzando HUD Maestro..."
echo "🚀 Backend HUD Maestro corriendo en http://localhost:3000"
echo "📊 Marcador sesión → 🚀 Activaciones: 0 | 🔗 Clicks: 0 | 🎉 Hitos: 0"
echo "✅ HUD Maestro listo. Backend PID $BACKEND_PID"
echo "📡 Eventos en vivo + marcador; Ctrl+C para detener."

# 6) Archivo meta.json inicial
echo '{"meta":"inicio","timestamp":0}' > meta.json
echo "📁 Archivo meta.json creado para sincronización de confeti"
