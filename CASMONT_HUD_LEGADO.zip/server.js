const express = require('express');
const cors = require('cors');
const bodyParser = require('body-parser');
const sqlite3 = require('sqlite3').verbose();

const app = express();
const PORT = process.env.PORT || 3000;
app.use(cors());
app.use(bodyParser.json());
app.use(express.static('.'));

function getDB() {
  return new sqlite3.Database('hud.db');
}

app.get('/api/metricas', (req, res) => {
  const db = getDB();
  db.all(`SELECT clave, valor FROM metricas`, [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    const data = {};
    rows.forEach(r => data[r.clave] = r.valor);
    res.json(data);
    db.close();
  });
});

app.get('/api/export', (req, res) => {
  const db = getDB();
  db.all(`SELECT * FROM hitos`, [], (err, rows) => {
    if (err) return res.status(500).json({error: err.message});
    res.json(rows);
    db.close();
  });
});

app.post('/api/eventos', (req, res) => {
  const { solucion, tipo, fecha } = req.body;
  console.log(`📌 Evento recibido: ${solucion} - ${tipo} @ ${fecha}`);
  if (tipo === 'activacion') {
    const key = `activaciones-${solucion}`;
    const db = getDB();
    db.get(`SELECT valor FROM metricas WHERE clave=?`, [key], (err, row) => {
      if (!err && row) {
        const nuevo = parseInt(row.valor) + 1;
        db.run(`UPDATE metricas SET valor=? WHERE clave=?`, [nuevo.toString(), key]);
        console.log(`✅ Activaciones de ${solucion}: ${nuevo}`);
      }
      db.close();
    });
  }
  res.json({ status: 'ok' });
});

app.post('/api/hitos', (req, res) => {
  const { solucion, hito, fecha } = req.body;
  console.log(`🏆 Hito registrado: ${hito} para ${solucion} @ ${fecha}`);
  const db = getDB();
  db.run(`INSERT INTO hitos (solucion, hito, fecha) VALUES (?, ?, ?)`, [solucion, hito, fecha]);
  db.close();
  const nft = { nombre: `NFT-${Date.now()}` };
  res.json({ nft });
});

app.listen(PORT, () => console.log(`🚀 Backend HUD Maestro corriendo en http://localhost:${PORT}`));
